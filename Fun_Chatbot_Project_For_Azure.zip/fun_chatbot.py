
import random
import time

greetings = ["Hey there!", "Hello!", "Hi!", "Heyyy! 😄", "Yo!"]
jokes = [
    "Why don't scientists trust atoms? Because they make up everything! 😂",
    "What do you call fake spaghetti? An impasta! 🍝",
    "Why did the computer go to therapy? Because it had too many bytes. 🧠💻",
]
goodbyes = ["Bye!", "See you later!", "Catch you soon!", "Take care! 👋", "See ya later, alligator! 🐊"]

def chatbot():
    print("🤖 FunBot: Hello! I'm FunBot. Let's chat. (type 'exit' to stop)")
    while True:
        user = input("You: ").lower()
        time.sleep(0.5)
        if "hello" in user or "hi" in user:
            print("FunBot:", random.choice(greetings))
        elif "joke" in user:
            print("FunBot:", random.choice(jokes))
        elif "bye" in user or "exit" in user:
            print("FunBot:", random.choice(goodbyes))
            break
        else:
            print("FunBot: That's interesting! Tell me more 😄")

chatbot()
